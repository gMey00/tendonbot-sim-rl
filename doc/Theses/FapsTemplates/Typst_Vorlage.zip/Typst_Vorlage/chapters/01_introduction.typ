// Chapter 1 — Introduction
// Demonstrates: numbered headings, acronym first-use expansion, citations,
// numbered (enum) lists and cross-references.
#import "../lib/macros.typ": *
#import "../lib/acronyms.typ": *

= Introduction <ch:introduction>

This chapter shows the basic building blocks of the template. Replace its
content with your own. The first time an abbreviation is used through
`ac()` it is expanded automatically — for example #ac("RL") — and every
later use prints only the short form: #ac("RL"). Abbreviations registered
this way are collected into the List of Abbreviations at the front of the
document.

== Motivation and Context

Open a paragraph of running text here. Citations use Typst's reference
syntax and resolve against `bibliography.bib`; cite a single source like
@SuttonBarto2018 or several at once~@Mittal2025IsaacLab @SuttonBarto2018.
The bibliography is formatted with the FAPS ISO 690 numeric style
(see #link("https://typst.app")[the project README] for details).

The #ac("FAPS") thesis structure expects an introduction that motivates the
work, states the problem and outlines the remaining chapters.

== Problem Statement and Objectives

State the research problem and then enumerate the objectives. Numbered lists
use the FAPS green markers:

+ *First objective:* a concise, verb-first statement of what is delivered.
+ *Second objective:* the next deliverable, again stated precisely.
+ *Third objective:* and so on.

== Thesis Outline

The remainder is organised as follows. @ch:fundamentals introduces the
formatting features of the template, including figures, tables, equations and
algorithms. @ch:conclusion summarises the work and gives an outlook. Use
`@label` to cross-reference any headed, captioned or labelled element.
