// FAPS Cover Page (Deckblatt)
// Recreates the official FAPS title page layout faithfully.
// Coordinates are derived from the LaTeX `textblock*` absolute positions.

#import "colors.typ": *

// Render the FAPS title page.
//
// Parameters:
//   title:        Thesis title (string or content).
//   thesis-type:  e.g. "Project Thesis", "Master Thesis", "Bachelor Thesis".
//   program:      Degree program, e.g. "Computational Engineering M. Sc.".
//   author:       Author full name.
//   student-id:   Matriculation number.
//   supervisors:  Array of content, one entry per supervisor line.
//   deadline:     Submission deadline (string).
//   duration:     Processing time in months (string/number).
//   title-image:  Optional cover image *as content*, e.g.
//                   image("assets/titelbild.png")
//                 The image path is resolved relative to the file that calls
//                 faps-coversheet (normally thesis.typ at the project root),
//                 so use a path relative to the project root. It is placed in
//                 a 16cm × 9cm box; set those dimensions on the image for a
//                 flush fit (see thesis.typ).
#let faps-coversheet(
  title: "",
  thesis-type: "",
  program: "",
  author: "",
  student-id: "",
  supervisors: (),
  deadline: "",
  duration: "",
  title-image: none,
) = {
  // The cover page uses its own zero margins to allow absolute placement
  // (LaTeX textblock* coordinates are measured from the page's top-left edge).
  set page(
    header: none,
    footer: none,
    numbering: none,
    margin: (top: 0cm, bottom: 0cm, left: 0cm, right: 0cm),
  )

  // FAPS green bar (top left) — LaTeX (1.3cm, 2.92cm), 1.5cm × 0.47cm
  place(
    top + left,
    dx: 1.3cm,
    dy: 2.92cm,
    rect(width: 1.5cm, height: 0.47cm, fill: fapsgruen),
  )

  // FAPS logo (top right) — LaTeX (16.6cm, 1.4cm)
  place(
    top + left,
    dx: 16.6cm,
    dy: 1.4cm,
    image("../assets/LogoFAPS.png", width: 3cm, height: 3cm),
  )

  // Title — aligned with the green bar's top edge
  place(
    top + left,
    dx: 3.0cm,
    dy: 2.92cm,
    block(width: 13cm)[
      #set text(size: 17pt, weight: "bold")
      #set par(leading: 0.5em, justify: true)
      #title
    ],
  )

  // Thesis type and program
  place(
    top + left,
    dx: 3.0cm,
    dy: 6.5cm,
    block(width: 13cm)[
      #set text(weight: "bold", size: 11pt)
      #set par(leading: 0.5em)
      #thesis-type in the program #program
    ],
  )

  // University / chair info
  place(
    top + left,
    dx: 3.0cm,
    dy: 8.5cm,
    block(width: 16cm)[
      #set text(weight: "bold", size: 11pt)
      #set par(leading: 0.5em)
      Friedrich-Alexander-Universität Erlangen-Nürnberg \
      Lehrstuhl für Fertigungsautomatisierung und Produktionssystematik \
      Prof. Dr.-Ing. J. Franke
    ],
  )

  // Title image (16cm × 9cm box) — LaTeX (3cm, 11.65cm)
  if title-image != none {
    place(
      top + left,
      dx: 3.0cm,
      dy: 11.65cm,
      box(width: 16cm, height: 9cm, clip: true, title-image),
    )
  }

  // Metadata table — LaTeX (3cm, 21.1cm)
  place(
    top + left,
    dx: 3.0cm,
    dy: 21.1cm,
    block(width: 16cm)[
      #set text(size: 11pt)
      #set par(leading: 0.5em)
      #grid(
        columns: (3.5cm, 7cm, 1fr),
        row-gutter: 0.6em,
        [Author:], [#author], align(right)[Student ID: #student-id],
        [], [], [],
        [Supervisors:], supervisors.at(0, default: []), [],
        ..if supervisors.len() > 1 { supervisors.slice(1).map(s => ([], s, [])).flatten() },
        [], [], [],
        [Deadline:], [#deadline], [],
        [Duration:], [#duration months], [],
      )
    ],
  )

  pagebreak()
  // Blank back of cover
  page(header: none, footer: none, numbering: none, margin: auto)[]
}
