// =====================================================================
//  FAPS Thesis — Typst Template (standalone)
//  Friedrich-Alexander-Universität Erlangen-Nürnberg
//  Lehrstuhl für Fertigungsautomatisierung und Produktionssystematik
// ---------------------------------------------------------------------
//  Build:   make            (or: just, or the typst command below)
//           typst compile thesis.typ --root . thesis.pdf
//  See README.md for full usage instructions.
// =====================================================================

#import "lib/template.typ": *
#import "lib/colors.typ": *
#import "lib/macros.typ": *
#import "lib/acronyms.typ": *
#import "lib/coversheet.typ": faps-coversheet
#import "lib/erklaerung.typ": erklaerung

// ── Metadata ─────────────────────────────────────────────────────────
//  Edit these values for your thesis.
#let thesis-title      = "Title of the Thesis — Possibly Spanning Two Lines"
#let thesis-type       = "Master Thesis"            // or "Project Thesis", "Bachelor Thesis"
#let thesis-program    = "Computational Engineering M. Sc."
#let thesis-author     = "Vorname Nachname"
#let thesis-student-id = "01234567"
#let thesis-deadline   = "01.07.2026"
#let thesis-duration   = "6"                        // processing time in months

// ── Apply the FAPS template ──────────────────────────────────────────
#show: faps-thesis.with(
  title: thesis-title,
  author: thesis-author,
  language: "en",                                   // "en" or "de"
)

// ── Cover page ───────────────────────────────────────────────────────
//  The cover image is passed as content; its path is relative to THIS file.
//  Replace assets/titelbild_placeholder.png with your own cover image.
#faps-coversheet(
  title: thesis-title,
  thesis-type: thesis-type,
  program: thesis-program,
  author: thesis-author,
  student-id: thesis-student-id,
  supervisors: (
    [Prof. Dr.-Ing. J. Franke],
    [M.Sc. Supervisor Name],
  ),
  deadline: thesis-deadline,
  duration: thesis-duration,
  title-image: image("assets/titelbild_placeholder.png", width: 16cm, height: 9cm),
)

// ── Declaration of authenticity (with AI-usage disclosure) ───────────
//  Tick the applicable AI-usage boxes inside lib/erklaerung.typ
//  by changing "[ ]" to "[X]".
#erklaerung(name: thesis-author, student-id: thesis-student-id)

// ── Front matter (roman numerals, no chapter header) ─────────────────
#show: faps-frontmatter

#faps-toc()      // Table of Contents
#faps-lof()      // List of Figures
#faps-lot()      // List of Tables
#faps-loa()      // List of Algorithms (only printed if any exist)

// Abbreviations and symbols (auto-filtered to those actually used)
#print-abbreviations()
#print-symbols()

// ── Main matter (arabic numerals, running header/footer) ─────────────
#show: faps-header-footer
#counter(page).update(1)

#include "chapters/01_introduction.typ"
#include "chapters/02_fundamentals.typ"
#include "chapters/03_conclusion.typ"

// ── Bibliography ─────────────────────────────────────────────────────
#bibliography("bibliography.bib", style: "assets/iso690-numeric-alphabetical.csl")

// ── Appendices ───────────────────────────────────────────────────────
#_in-appendix.update(true)
#include "chapters/appendices.typ"
