// Chapter 3 — Summary and Outlook
#import "../lib/macros.typ": *
#import "../lib/acronyms.typ": *

= Summary and Outlook <ch:conclusion>

Summarise the contributions of the work in a few paragraphs, restating the
objectives from @ch:introduction and how each was met.

== Summary

Recapitulate the key results without introducing new material.

== Outlook

Close with concrete directions for future work. This mirrors the
"Zusammenfassung und Ausblick" section expected by the FAPS structure.
