// Acronym & Symbol System for Typst
// ============================================================
// Provides automatic first-use expansion: the first use of ac("RL") renders
// "Reinforcement Learning (RL)", every later use renders just "RL".
// It also produces auto-filtered lists of abbreviations and symbols: only
// entries actually referenced (via ac/acs/acl/acp/reg-sym) appear in the lists.
//
// Implementation note: usage detection works by emitting an invisible
// metadata marker on every access and querying those markers. This is
// layout-convergence-stable (unlike state.final()).
//
// ── How to extend ────────────────────────────────────────────────
// Add entries to the `acronyms` dictionary below.
//   Abbreviation: (short: "RL", long: "Reinforcement Learning", tag: "abbrev")
//   With plural:  add `plural: "Degrees of Freedom"` to override the default "+s".
//   Symbol:       key prefixed "sym:", `short` is math content, tag: "symbol".

// Label used to tag all acronym-usage metadata elements
#let _ac-used-label = <_ac-used>

// Emit an invisible usage marker
#let _ac-marker(key) = [#metadata(key)#_ac-used-label]

// Acronym & symbol database. Replace these example entries with your own.
#let acronyms = (
  // ── Abbreviations ──────────────────────────────────────────────
  "FAPS": (short: "FAPS", long: "Institute for Factory Automation and Production Systems", tag: "abbrev"),
  "RL":   (short: "RL",   long: "Reinforcement Learning",        tag: "abbrev"),
  "CAD":  (short: "CAD",  long: "Computer-Aided Design",         tag: "abbrev"),
  "GPU":  (short: "GPU",  long: "Graphics Processing Unit",      tag: "abbrev"),
  "DoF":  (short: "DoF",  long: "Degree of Freedom",             tag: "abbrev", plural: "Degrees of Freedom"),
  "API":  (short: "API",  long: "Application Programming Interface", tag: "abbrev"),

  // ── Symbols (short = math content) ─────────────────────────────
  "sym:gamma": (short: $gamma$,      long: "Discount factor",        tag: "symbol"),
  "sym:theta": (short: $theta$,      long: "Model parameters",       tag: "symbol"),
  "sym:M":     (short: $bold(M)$,    long: "Mass matrix",            tag: "symbol"),
)

// -- Acronym access functions -------------------------------------------------

// First-use expansion: "Long Form (Short)" → subsequent uses: "Short".
#let ac(key) = context {
  let entry = acronyms.at(key)
  let prev = query(selector(_ac-used-label).before(here()))
    .filter(m => m.value == key)
  if prev.len() > 0 {
    [#_ac-marker(key)#entry.short]
  } else {
    [#_ac-marker(key)#entry.long (#entry.short)]
  }
}

// Always short form — also emits usage marker.
#let acs(key) = [#_ac-marker(key)#acronyms.at(key).short]

// Always long form — also emits usage marker.
#let acl(key) = [#_ac-marker(key)#acronyms.at(key).long]

// Plural form (first use expanded) — also emits usage marker.
#let acp(key) = context {
  let entry = acronyms.at(key)
  let long-plural = if "plural" in entry { entry.plural } else { entry.long + "s" }
  let prev = query(selector(_ac-used-label).before(here()))
    .filter(m => m.value == key)
  if prev.len() > 0 {
    [#_ac-marker(key)#entry.short\s]
  } else {
    [#_ac-marker(key)#long-plural (#entry.short\s)]
  }
}

// Kept for API compatibility; first-use detection is purely positional.
#let ac-reset() = {}

// Register one or more symbol keys for the List of Symbols without showing
// any visible output. Use this for symbols that appear only inside math
// equations (where acs()/ac() cannot be used inline).
// Example: #reg-sym("sym:gamma", "sym:theta")
#let reg-sym(..keys) = {
  for key in keys.pos() {
    _ac-marker(key)
  }
}

// -- Print lists (auto-filtered to used entries only) -------------------------

// Print list of abbreviations — only entries used in this document.
#let print-abbreviations() = context {
  let used = query(_ac-used-label).map(m => m.value).dedup()
  let abbrevs = acronyms
    .pairs()
    .filter(((k, v)) => v.tag == "abbrev" and used.contains(k))
    .sorted(key: ((k, v)) => v.short)
  if abbrevs.len() > 0 {
    heading(numbering: none)[List of Abbreviations]
    for (key, entry) in abbrevs {
      grid(
        columns: (2.5cm, 1fr),
        gutter: 0.5cm,
        text(entry.short), text(entry.long),
      )
      v(0.1em)
    }
  }
}

// Print list of symbols — only entries used in this document.
#let print-symbols() = context {
  let used = query(_ac-used-label).map(m => m.value).dedup()
  let syms = acronyms
    .pairs()
    .filter(((k, v)) => v.tag == "symbol" and used.contains(k))
    .sorted(key: ((k, v)) => str(k))
  if syms.len() > 0 {
    heading(numbering: none)[List of Symbols]
    for (key, entry) in syms {
      grid(
        columns: (2.5cm, 1fr),
        gutter: 0.5cm,
        entry.short, text(entry.long),
      )
      v(0.1em)
    }
  }
}
