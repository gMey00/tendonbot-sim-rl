// Chapter 2 — Formatting features (showcase)
// Demonstrates: sections/subsections, paragraph headings, bullet lists,
// figures and tables with short captions, numbered equations and symbols,
// multi-panel subfigures, algorithms, text macros and cross-references.
#import "../lib/macros.typ": *
#import "../lib/acronyms.typ": *
#import "../lib/template.typ": faps-figure, faps-table, faps-subfigure, faps-algorithm
#import "@preview/lovelace:0.3.1": pseudocode-list

= Formatting Features <ch:fundamentals>

This chapter exists purely to demonstrate the template's capabilities. Body
text is justified 11 pt Helvetica with FAPS-style headings. Inline emphasis
uses `*bold*` and `_italic_`; the #significant[significant] macro bolds key
terms, #english[engineering] adds an English gloss, and #todo[TODO markers]
stand out in red for drafting.

== Lists and Headings

Unnumbered bullet lists use the FAPS green square markers:

- A first point.
- A second point, with a nested level:
  - A sub-point that uses the smaller marker.
- A third point.

=== Sub-subsection

Headings are numbered to three levels (e.g. 2.2.1). A fourth level renders as
an unnumbered, bold paragraph lead-in:

==== Paragraph heading
Text continues on its own line after a level-4 heading.

== Figures

Insert a figure with `faps-figure`. The `caption` is shown under the figure
in the text, while the optional `short-caption` is what appears in the List of
Figures. Reference figures with `@label`, e.g. @fig:logo.

#faps-figure(
  image("../assets/LogoFAPS.png", width: 3cm),
  caption: [The FAPS logo, shown here to demonstrate a figure with a long
            in-text caption that differs from its List-of-Figures entry.],
  short-caption: [FAPS logo],
) <fig:logo>

Every figure and table should be referenced in the text. @fig:logo shows the
institute logo.

== Tables

Tables use a FAPS-green header row. Use `faps-table` so the entry is collected
into the List of Tables; @tab:example summarises the available helpers.

#faps-table(
  table(
    columns: (auto, 1fr),
    table.header([*Helper*], [*Purpose*]),
    [`faps-figure`],    [Figure with separate in-text / List-of-Figures captions.],
    [`faps-table`],     [Table with the same short-caption mechanism.],
    [`faps-subfigure`], [Multi-panel figure with auto-lettered sub-captions.],
    [`faps-algorithm`], [Numbered pseudocode block (List of Algorithms).],
  ),
  caption: [Overview of the figure, table and algorithm helper functions
            provided by the template.],
  short-caption: [Template helper functions],
) <tab:example>

== Equations and Symbols

Numbered equations are produced with `$ ... $` in block form. Symbols can be
registered for the List of Symbols with `reg-sym` so they appear there even
when they only occur inside math:

#reg-sym("sym:gamma", "sym:theta", "sym:M")

$ J(theta) = EE [ sum_(t=0)^infinity gamma^t r_t ] $ <eq:return>

@eq:return defines the expected discounted return, where $gamma$ is the
discount factor and $theta$ the model parameters.

== Multi-Panel Figures

Use `faps-subfigure` for side-by-side panels with automatic (a)/(b) labels.
Pass the outer label via the `label:` argument (not a trailing `<...>`).

#faps-subfigure(
  columns: (1fr, 1fr),
  panels: (
    (image("../assets/LogoFAPS.png", width: 2.5cm), [First panel.]),
    (image("../assets/LogoFAPS.png", width: 2.5cm), [Second panel.]),
  ),
  caption: [A two-panel figure demonstrating automatic sub-captioning.],
  short-caption: [Two-panel example],
  label: <fig:panels>,
)

@fig:panels shows two panels referenced as a single figure.

== Algorithms

Pseudocode is written with `pseudocode-list` and wrapped in `faps-algorithm`
to obtain a numbered, captioned block listed in the List of Algorithms.

#faps-algorithm(
  pseudocode-list[
    + *for* each iteration *do*
      + observe the current state $s$
      + choose an action $a$
      + apply $a$ and record the outcome
    + *end for*
  ],
  caption: [A minimal training loop, shown to demonstrate the algorithm
            helper and the List of Algorithms.],
  short-caption: [Minimal training loop],
) <alg:loop>
