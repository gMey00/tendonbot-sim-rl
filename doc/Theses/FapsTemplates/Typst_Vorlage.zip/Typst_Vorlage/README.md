# FAPS Thesis — Typst Template

A standalone [Typst](https://typst.app) template for theses at the
**Lehrstuhl für Fertigungsautomatisierung und Produktionssystematik (FAPS)**,
Friedrich-Alexander-Universität Erlangen-Nürnberg.

It reproduces the formatting of the official FAPS Word/LaTeX templates (cover
page, declaration of authenticity, table of contents, lists of figures/tables/
algorithms/abbreviations/symbols, FAPS colours and heading styles, ISO 690
numeric citations) and adds Typst-native conveniences such as automatic
acronym expansion and short/long figure captions.

The project is **self-contained**: everything needed to build lives in this
directory, there are no shared dependencies, and it produces a single
`thesis.pdf` (no separate guideline document).

---

## 1. Prerequisites

- **Typst** ≥ 0.12 — install with `brew install typst`, `cargo install typst-cli`,
  `winget install Typst.Typst`, or download from
  <https://github.com/typst/typst/releases>.
- The template packages (`subpar`, `lovelace`) are fetched automatically from
  the Typst package registry on first compile — an internet connection is
  required once.
- **Fonts:** the body font is *Helvetica Neue / Helvetica / Arial* (matching the
  FAPS look). On a system without Helvetica, Typst substitutes a default sans
  font and prints a harmless `unknown font family` warning. To use a bundled
  font, place the `.ttf`/`.otf` files in a folder and add
  `--font-path <folder>` to the compile command.

## 2. Building

From this directory, any of the following produce `thesis.pdf`:

```bash
make            # uses the Makefile
just            # uses the justfile
typst compile thesis.typ --root . thesis.pdf
```

Live preview that rebuilds on every save:

```bash
make watch      # or:  just watch  /  typst watch thesis.typ --root . thesis.pdf
```

> **`--root .`** bounds all file and image access to this directory, which is
> why the template is portable — copy the folder anywhere and it still builds.

`make clean` removes the generated PDF.

## 3. Project structure

```
Typst_Vorlage/
├── thesis.typ            ← main document: metadata + document assembly (start here)
├── bibliography.bib      ← your references (cited with @key)
├── Makefile / justfile   ← build recipes
├── assets/
│   ├── LogoFAPS.png                    FAPS logo (cover page)
│   ├── titelbild_placeholder.png       cover image — replace with your own
│   └── iso690-numeric-alphabetical.csl FAPS ISO 690 citation style
├── lib/                  ← formatting engine (rarely needs editing)
│   ├── template.typ        page layout, headings, figure/table/algorithm helpers, TOC & lists
│   ├── colors.typ          official FAPS colour palette
│   ├── macros.typ          text/math helper macros
│   ├── acronyms.typ        acronym & symbol database + auto-expansion
│   ├── coversheet.typ      FAPS title page
│   └── erklaerung.typ      declaration of authenticity (incl. AI-usage checklist)
└── chapters/
    ├── 01_introduction.typ   demonstrates acronyms, citations, lists, cross-refs
    ├── 02_fundamentals.typ   demonstrates figures, tables, equations, subfigures, algorithms
    ├── 03_conclusion.typ
    └── appendices.typ        appendix numbering (A, B, …)
```

Write your thesis by editing the metadata block in `thesis.typ` and replacing
the example `chapters/`. The files in `lib/` implement the styling and normally
do not need changes.

## 4. Filling in your thesis

All thesis metadata lives at the top of **`thesis.typ`**:

```typ
#let thesis-title      = "…"
#let thesis-type       = "Master Thesis"   // or "Project Thesis", "Bachelor Thesis"
#let thesis-program    = "Computational Engineering M. Sc."
#let thesis-author     = "Vorname Nachname"
#let thesis-student-id = "01234567"
#let thesis-deadline   = "01.07.2026"
#let thesis-duration   = "6"               // months
```

- **Document language:** set `language: "en"` or `"de"` in the
  `#show: faps-thesis.with(...)` call.
- **Cover image:** replace `assets/titelbild_placeholder.png` and adjust the
  `image(...)` path in the `faps-coversheet` call. It is passed as content, so
  the path is relative to `thesis.typ`; the image is placed in a 16 × 9 cm box.
- **Supervisors:** edit the `supervisors:` array (one entry per line).
- **Adding chapters:** create a file in `chapters/` and add an `#include` line
  in the *Main matter* section of `thesis.typ`.

## 5. Declaration of authenticity & AI-usage checklist

`lib/erklaerung.typ` renders the German *Erklärung*. The author name and
matriculation number are filled automatically from the metadata.

It contains the mandatory AI-usage disclosure as a **checklist with tickable
boxes**. Toggle a box directly in the source by editing its marker —
Markdown-style:

```typ
ai-option("[ ]")[…]   // unchecked  → empty grey box
ai-option("[X]")[…]   // checked    → blue box with ✗
```

Edit the markers in `lib/erklaerung.typ` to reflect how you actually used AI
tools. Both `[X]` and `[x]` count as checked.

## 6. Writing content — feature reference

Import the helpers you need at the top of a chapter file:

```typ
#import "../lib/macros.typ": *
#import "../lib/acronyms.typ": *
#import "../lib/template.typ": faps-figure, faps-table, faps-subfigure, faps-algorithm
```

### Headings, lists, text

- Headings: `= H1`, `== H2`, `=== H3` are numbered to three levels; `==== H4`
  is an unnumbered bold paragraph lead-in.
- Bullet lists (`-`) use the FAPS green square markers; numbered lists use `+`.
- Macros from `macros.typ`: `#significant[…]` (bold key term),
  `#english[…]` *(engl. …)*, `#todo[…]` (red draft marker), `#name[…]`
  (small caps), plus math helpers (`#vecbold`, `#einheit`, …).

### Acronyms & symbols (`acronyms.typ`)

| Call | Output |
|------|--------|
| `#ac("RL")` | first use → *Reinforcement Learning (RL)*, later → *RL* |
| `#acs("RL")` / `#acl("RL")` | always short / always long |
| `#acp("DoF")` | plural form |
| `#reg-sym("sym:gamma")` | register a symbol for the List of Symbols (no output) |

Only entries actually used appear in the auto-generated **List of
Abbreviations** and **List of Symbols**. Add your own entries to the
`acronyms` dictionary in `lib/acronyms.typ`.

### Figures & tables (short vs. long captions)

`faps-figure` / `faps-table` accept a long `caption:` (shown under the element)
and an optional `short-caption:` (used in the List of Figures/Tables):

```typ
#faps-figure(
  image("../assets/plot.png", width: 80%),
  caption: [A long, descriptive caption shown in the text.],
  short-caption: [Short caption for the list],
) <fig:plot>
```

Reference with `@fig:plot`. Tables use a FAPS-green header row automatically.
**Always reference every figure and table in the text.**

### Multi-panel figures

```typ
#faps-subfigure(
  columns: (1fr, 1fr),
  panels: (
    (image("../assets/a.png"), [Panel a]),
    (image("../assets/b.png"), [Panel b]),
  ),
  caption: [Outer caption.],
  short-caption: [Short],
  label: <fig:panels>,   // pass the outer label here, NOT as a trailing <…>
)
```

### Equations & algorithms

```typ
$ J(theta) = EE [ sum_(t=0)^infinity gamma^t r_t ] $ <eq:return>
```

Pseudocode (collected into the List of Algorithms):

```typ
#import "@preview/lovelace:0.3.1": pseudocode-list
#faps-algorithm(
  pseudocode-list[ + *for* each step *do* … ],
  caption: [Training loop.],
  short-caption: [Loop],
) <alg:loop>
```

## 7. Citations & bibliography

References live in `bibliography.bib` (BibLaTeX format) and are cited with
`@key` or `@key1 @key2`. The display style is the FAPS **DIN ISO 690 numeric**
style, configured in `thesis.typ`:

```typ
#bibliography("bibliography.bib", style: "assets/iso690-numeric-alphabetical.csl")
```

## 8. Document structure (FAPS order)

The template assembles the document in the order expected by FAPS:

1. Cover page (`faps-coversheet`)
2. Declaration of authenticity (`erklaerung`)
3. Front matter (roman numerals): Table of Contents, Lists of Figures /
   Tables / Algorithms / Abbreviations / Symbols
4. Main matter (arabic numerals, running header): your chapters
5. Bibliography
6. Appendices (re-numbered A, B, …; excluded from the front-matter lists)

---

*Adapted from the FAPS thesis sources by Georg Meyer. The styling in `lib/`
mirrors the official FAPS Word and LaTeX templates.*
