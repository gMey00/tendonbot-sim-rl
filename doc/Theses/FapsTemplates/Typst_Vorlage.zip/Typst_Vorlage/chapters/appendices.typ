// Appendices
// Appendix headings are re-numbered as "A", "B", … and excluded from the
// front-matter lists (the `_in-appendix` flag is set in thesis.typ before
// this file is included).
#import "../lib/macros.typ": *
#import "../lib/acronyms.typ": *
#import "../lib/template.typ": faps-table

// Restart heading numbering with letters for the appendix.
#set heading(numbering: "A.1")
#counter(heading).update(0)

= Supplementary Data <appendix:data>

Place large tables, parameter listings or derivations that would interrupt
the main text here. Figures and tables in the appendix are intentionally
kept out of the front-matter lists.

= Contents of the Data Medium <appendix:medium>

Following the FAPS structure, the final appendix typically lists the contents
of the accompanying data medium:

- Digital version of the thesis (Word/Typst sources and PDF).
- Editable source files for all graphics.
- Data sheets and CAD models.
- Source code and datasets.
